import SpriteKit

/** 
 Modelo matemático de uma Rosa Polar
 
 - Author: Pedro Cacique
 - Date: 22/03/2020
 - Version: 1.0.0
 */
public class Rose{
    var center: CGPoint
    var radius: CGFloat
    var n: CGFloat
    var d: CGFloat
    var angle: CGFloat = 0
    var step: CGFloat = 0.05
    private var points: [CGPoint] = []
    
    init(center:CGPoint, radius:CGFloat, n:CGFloat, d:CGFloat){
        self.center = center
        self.radius = radius
        self.n = n
        self.d = d
        generatePoints()
    }
    
    func generatePoints(){
        points = []
        for i in 0...1500{
            var r = radius * cos((n/d) * angle)
            angle += step
            let x = center.x + r * cos(angle)
            let y = center.y + r * sin(angle)
            points.append(CGPoint(x:x, y:y))
        } 
    }
    
    public func getPoints() -> [CGPoint]{
        return self.points
    }
}
