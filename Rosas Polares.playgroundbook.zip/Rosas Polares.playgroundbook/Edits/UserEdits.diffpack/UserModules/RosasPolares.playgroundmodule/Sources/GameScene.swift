import SpriteKit

public class GameScene: SKScene{
    
    var colors:[UIColor] = [#colorLiteral(red: 0.9764705882352941, green: 0.8509803921568627, blue: 0.5490196078431373, alpha: 1.0),#colorLiteral(red: 0.9098039215686274, green: 0.47843137254901963, blue: 0.6431372549019608, alpha: 1.0),#colorLiteral(red: 0.25882352941176473, green: 0.7568627450980392, blue: 0.9686274509803922, alpha: 1.0),#colorLiteral(red: 0.5568627450980392, green: 0.35294117647058826, blue: 0.9686274509803922, alpha: 1.0),#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0),#colorLiteral(red: 0.7215686274509804, green: 0.8862745098039215, blue: 0.592156862745098, alpha: 1.0)]
    override public func didMove(to view: SKView) {
        self.backgroundColor = #colorLiteral(red: 0.03529411764705882, green: 0.11764705882352941, blue: 0.16470588235294117, alpha: 1.0)

        var x = 100
        var y = 100
        for j in 1...8{
            for i in 1...20{
                let r = Rose(center: CGPoint(x:x, y:y), radius: CGFloat.random(in: 30...100), n: CGFloat(i), d: CGFloat(j))
                drawShape(points: r.getPoints(), lineWidth: CGFloat.random(in: 1...5), color: colors[Int.random(in:0...colors.count-1)])
                x += 125
            }
            y += 125
            x = 100
        }
    }
    
    func drawShape(points:[CGPoint], lineWidth:CGFloat = 1, color:UIColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)){
        var shape = SKShapeNode()
        var path = CGMutablePath()
        if points.count > 0 {
            path.move(to: points[0])
            for p in points{
                path.addLine(to: p)
            }
        }
        shape.path = path
        shape.strokeColor = color
        shape.lineWidth = lineWidth
        addChild(shape)
    }
}
